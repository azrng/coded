class ticketIsExitsException(Exception):
    pass